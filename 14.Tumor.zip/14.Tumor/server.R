#-------------------------------------------------------------------------
#  This application is governed by the CeCILL-B license. 
#  You can  use, modify and/ or redistribute this code under the terms
#  of the CeCILL license:  http://www.cecill.info/index.en.html
#
#  Marc Lavielle, Inria Saclay
#  April 30th, 2015
#-------------------------------------------------------------------------

library(mlxR)

shinyServer(function(input, output) {

  r <- reactive({  
    param.value=c(input$K,input$KDE,input$KPQ,input$KQPP,input$LAMBDAP,input$GAMMA,input$DELTAQP)
    t.value=seq(input$range[1],input$range[2],length.out=input$ngp)

    t11=0
    t12=input$ii1*(input$nd1-1)+t11
    if (t12>=t11){
      t1.dose=seq(t11,t12,by=input$ii1)
      adm1 <- list(time=t1.dose, amount=input$amt1)
    }else{
      adm1 <- list(time=t11, amount=0, type=1)
    }
    t21=0
    t22=input$ii2*(input$nd2-1)+t21
    if (t22>=t21){
      t2.dose=seq(t21,t22,by=input$ii2)
      adm2 <- list(time=t2.dose, amount=input$amt2)
    }else{
      adm2 <- list(time=t21, amount=0, type=2)
    }
    
    g <- list(list(treatment=adm1),list(treatment=adm2))
    f  <- list(name=c('PSTAR','PT','Q','QP'),time=t.value)
    p   <- list(name=c('K','KDE','KPQ','KQPP','LAMBDAP','GAMMA','DELTAQP'), value=param.value)
    
    res <- simulx( model     = 'tgi_model.txt',
                   group = g, 
                 parameter = p,
                 output    = f)
    res
  })
  
  output$plot <- renderPlot({
    r=r()
    r <- r[[input$output]]
    j<-which(names(r)==input$output)
    names(r)[j] <- "f"
    pl=ggplotmlx(data=r, aes(x=time, y=f, colour=id)) + geom_line(size=0.75) +
      theme(legend.position=c(.1, .9))
    print(pl)
  })

output$table <- renderTable({ 
  r <- r()
  d <- merge(r$PSTAR,r$PT)
  d <- merge(d,r$Q)
  d <- merge(d,r$QP)
  return(d)
})

  
})