#-------------------------------------------------------------------------
#  This application is governed by the CeCILL-B license. 
#  You can  use, modify and/ or redistribute this code under the terms
#  of the CeCILL license:  http://www.cecill.info/index.en.html
#
#  Marc Lavielle, Inria Saclay
#  April 29th, 2015
#-------------------------------------------------------------------------
library(mlxR)
shinyUI(fluidPage(
  titlePanel(
    list(HTML('<p style="color:#4C0B5F; font-size:24px">Tumor growth inhibition model</p>
              <p style="color:#4C0B5F; font-size:18px">Comparing 2 dosage regimens</p>' )),
    windowTitle="tumor growth II"),
  navbarPage("", selected="Plot", id="nav", inverse="FALSE", 
             tabPanel("Plot",
                      tabsetPanel( id="tabs", type="pills",
                                   tabPanel("regimen 1"),
                                   tabPanel("regimen 2"),
                                   tabPanel("parameters"),
                                   tabPanel("output")
                      ),
                      fluidRow(
                        column(3,
                               br(), br(),
                               conditionalPanel(condition="input.tabs=='regimen 1'",
                                                sliderInput("nd1", "Number of doses:", value=6, min=0, max = 20, step=1),
                                                sliderInput("ii1", "Interdose interval:", value = 12, min = 1, max = 20, step=1),
                                                sliderInput("amt1", "Amount:", value = 1, min = 0, max = 5, step=0.25),
                                                br()
                               ),
                               conditionalPanel(condition="input.tabs=='regimen 2'",
                                                sliderInput("nd2", "Number of doses:", value=6, min=0, max = 20, step=1),
                                                sliderInput("ii2", "Interdose interval:", value = 4, min = 1, max = 20, step=1),
                                                sliderInput("amt2", "Amount:", value = 1, min = 0, max = 5, step=0.25),
                                                br()
                               ),
                               
                               conditionalPanel(condition="input.tabs=='parameters'",
                                                sliderInput("GAMMA", "GAMMA:", value = 1, min = 0, max = 4, step=0.1), 
                                                sliderInput("K", "K:", value = 100, min = 0, max = 200, step=5),
                                                sliderInput("KDE", "KDE:", value = 0.3, min = 0, max = 1, step=0.05),
                                                sliderInput("LAMBDAP", "LAMBDAP:", value = 0.12, min = 0, max = 0.5, step=0.025) ,
                                                sliderInput("DELTAQP", "DELTAQP:", value = 0.01, min = 0, max = 0.05, step=0.0025),
                                                sliderInput("KPQ", "KPQ:", value = 0.025, min = 0, max = 0.1, step=0.005),
                                                sliderInput("KQPP", "KQPP:", value = 0.004, min = 0, max = 0.01, step=0.0005),
                                                br()
                               ),
                               
                               conditionalPanel(condition="input.tabs=='output'",
                                                radioButtons("output","",c("PSTAR" = "PSTAR","PT" = "PT","Q" = "Q","QP" = "QP")),
                                                br(),
                                                sliderInput("range", "time range", min = -100, max = 500, value = c(-50,200), step=10),
                                                br(),
                                                sliderInput("ngp", "grid size", min = 101, max = 1001, value = 501, step=100),
                                                br()
                               )
                        ),
                        column(9,
                               plotOutput("plot",  height="500px"))
                      )),
             tabPanel("Table", tableOutput("table")),
             navbarMenu("Codes",
                        tabPanel("Mlxtran", pre(includeText("tgi_model.txt"))),
                        tabPanel("ui.R", pre(includeText("ui.R"))),
                        tabPanel("server.R", pre(includeText("server.R"))
                        )
             ),
             tabPanel("ReadMe", withMathJax(), includeMarkdown("readMe.Rmd")),
             tabPanel("About", includeMarkdown("../../about/about.Rmd"))
  )
))
